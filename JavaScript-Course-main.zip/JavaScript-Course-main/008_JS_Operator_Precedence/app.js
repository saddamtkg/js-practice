// JavaScript Operator precedence
// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Operator_precedence
// ----- () {} []
// / * - +


/*
5 + 6 - 3 / 2 * 4
= 5+6-1.5*4
= 5+6-6
= 5 
console.log(5 + 6 - 3 / 2 * 4); // Ans: 5
*/
