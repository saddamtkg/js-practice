/*
 * JavaScript Strict Mode
 */
// 'use strict';

x = 5;
console.log(x);

name(5, 4);
function name(p1, p2) {
  // 'use strict';
  y = 5;
  console.log(p1, p2);
}

// let package = 'Some text';
// let public = 'Some text';
// let private = 'Some text';
