console.log('Hello');

document.getElementById('title').innerHTML = 'Hello World';

let sum = 150 + 40;
console.log(sum);

if (sum > 100) {
  console.log('Expensive');
} else {
  console.log('Cheep');
}

function sayHello(name) {
  console.log(`Hello ${name}`);
}
sayHello('Shovo');
