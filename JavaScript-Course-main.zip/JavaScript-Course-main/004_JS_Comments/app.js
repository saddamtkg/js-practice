// My First Comment

/*
 * Multi Line Comment
? Some info
! Waring
TODO: Some thing I need to fix
 */

let firstName = 'Ali';
let age = 30;

// firstName = 'Shovo'; // Changing firstName
FirstName = 'Hossain';
firstname = 'ali';
/*
console.log(firstName);

console.log(age + 50);
*/

function funcName() {
  console.log('My First Function');
}
funcName();
